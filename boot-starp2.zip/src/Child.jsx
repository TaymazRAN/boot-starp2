import React from "react";

const Child = () => {
  return (
    <div>
      <h1> تست بچه مامپوننت </h1>
    </div>
  );
};

export default Child;
