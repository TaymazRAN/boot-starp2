import React from "react";

const Gallery = () => {
  return (
    <div>
      <p> Gallery </p>
    </div>
  );
};

export default Gallery;
